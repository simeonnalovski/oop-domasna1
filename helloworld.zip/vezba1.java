class vezba1{
    public static void main(String[] args){
        System.out.println("Hello world!");
    }
}
//klasata hello world ima javen (public) pristap do podatocite
// static oznacuva deka sluzi za prikaz na objekt
//void oznacuva main metotodot nema povraten podatok (vo slucajov samo ispisuva hellow world)
// main go oznacuva main metodot
//String[] args oznacuva niza od strngovi
//System.out.println oznacuva deka sistemot ke izvadi ispecatena linija